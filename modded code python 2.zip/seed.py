def setSeed():#takes a seed value from the user
    exit = 1
    while exit == 1:
        try:
            setseed = int(raw_input("\nEnter a seed value\n"))
            exit = 0
            return setseed
        except ValueError:
            print "\nCOME ON MAN! GIVE ME SOMETHING REAL\n!"
            exit = 1

def setCommandLine():#usese regex to take a seed value from the CLI
    import sys
    import re

    seed_num, cmd_bool = 0, 0
    #"Enter three dashes(--) followed by a number, example: --1234, this is your seed value"
    for seeds in sys.argv:
        if (re.match(r'--', seeds)):
            seed_num = int(re.sub(r'--', '', seeds))
            print "Whoo, your seed from the command line was ", seed_num
            cmd_bool = 1
        else:
            print "No input from the command line? That's fine, \nnext time enter two dashes(--) after the filename followed by a number, \nexample: --1234, this is your seed value\n"
    return seed_num, cmd_bool

def randoSeed():
    import random
    myseed = random.randint(0, 10000)
    random.seed(myseed)
    print "This map seed is ", myseed
