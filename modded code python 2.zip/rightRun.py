def rightRun(mapz, mapsize, fitbit, i, j, direction):#implements a right and run algorithim
#as we can see the mapz value is passed from the makemap subroutine
	import makemap
	while fitbit < mapsize*mapsize and i>0 and j > 0 and i< mapsize-1 and j <mapsize-1:
		if direction == 'East':#for Right and Run
			if mapz[i+1][j] > 0:#if the straight path is clear, keep going
				i = i+1
				fitbit = fitbit+1
				direction = 'East'
			elif mapz[i][j-1] > 0:#if not, turn right
				j = j-1
				fitbit = fitbit+1
				direction = 'South'
			elif mapz[i][j+1] > 0:#and turn right again
				j = j+1
				fitbit = fitbit+1
				direction = 'North'
			else:
				i = i-1
				fitbit = fitbit+1#and so on
				direction = 'West'


		elif direction == 'North':#and so on, this also accounts for starting directions changing based on input
			if mapz[i][j+1] > 0:
				j = j+1
				fitbit = fitbit+1
				direction = 'North'
			elif mapz[i+1][j] > 0:
				i = i+1
				fitbit = fitbit+1
				direction = 'East'
			elif mapz[i-1][j] > 0:
				i = i-1
				fitbit = fitbit+1
				direction = 'West'
			else:
				j = j-1
				fitbit = fitbit+1
				direction = 'South'

		elif direction == 'West':
			if mapz[i-1][j] > 0:
				i = i-1
				fitbit = fitbit+1
				direction = 'West'
			elif mapz[i][j+1] > 0:
				j = j+1
				fitbit = fitbit+1
				direction = 'North'
			elif mapz[i][j-1] > 0:
				j = j-1
				fitbit = fitbit+1
				direction = 'South'
			else:
				i = i+1
				fitbit = fitbit+1
				direction = 'East'
		else:
			if mapz[i][j-1] > 0:
				j = j-1
				fitbit = fitbit+1
				direction = 'South'
			elif mapz[i-1][j] > 0:
				i = i-1
				fitbit = fitbit+1
				direction = 'West'
			elif mapz[i+1][j] > 0:
				i = i+1
				fitbit = fitbit+1
				direction = 'East'
			else:
				j = j+1
				fitbit = fitbit+1
				direction = 'North'
		mapz[i][j] = 8#sets each step on the map to 8
		

	exit = 0#This loop takes the map and givesthe user a decision to print it out using characters or numbers
	while exit == 0:
		yesno = raw_input("\nWould you like to print some cool stuff for Right-and-Run?\n")#prompts the user on whether they'd like to
		if yesno == 'no' or yesno == 'No' or yesno == 'n' or yesno == 'N':#see a better map
			printm = makemap.printmap(mapz)#if no, prints the regular map as per specifications
			exit = 1
		else:
			printm = makemap.printCool(mapz)#if yes, prints the map with predefined characters from makemap.printCool
			exit =1
		#	print mapz[i][j],

	if(fitbit == mapsize*mapsize):#if the algorithim is unable to escape after the mapsize^2 then quit
		print "QUIT, STOP FOR THE LOVE OF GOD!"
	else:#however if the algorithim is able to escape the cave, print how many steps it took
		print "You did it! Using the Right and Run method only took you ", fitbit, " steps, young man/woman/whatever."

	for i in range(len(mapz)):#resets the map back to its original format, with the center marked 5
		for j in range(len(mapz[i])):#also resets the step counter as well
			if mapz[i][j] !=0:
				mapz[i][j]=1
		mapz[mapsize/2][mapsize/2] =5
		fitbit =0
