def rightHandWall(mapz, mapsize, fitbit, i, j, direction):
    import random
    import makemap
    while fitbit < mapsize*mapsize and i>0 and j > 0 and i< mapsize-1 and j <mapsize-1:
        if direction == 'East' and fitbit < (mapsize*mapsize)/2:#for Right hand wall
            if mapz[i][j-1] > 0:#essentially the same principle as the right run
                j = j-1
                fitbit = fitbit+1#however this one waits until it hits a wall.
                direction = 'South'#then turns right
            elif mapz[i+1][j] > 0:
                i = i+1
                fitbit = fitbit+1
                direction = 'East'
            elif mapz[i][j+1] > 0:#and so on
                j = j+1
                fitbit = fitbit+1
                direction = 'North'
            else:
                i = i-1
                fitbit = fitbit+1
                direction = 'West'


        elif direction == 'North' and fitbit < (mapsize*mapsize)/2:
            if mapz[i+1][j] > 0:
                i = i+1
                fitbit = fitbit+1
                direction = 'East'
            elif mapz[i][j+1] > 0:
                j = j+1
                fitbit = fitbit+1
                direction = 'North'
            elif mapz[i-1][j] > 0:
                i = i-1
                fitbit = fitbit+1
                direction = 'West'
            else:
                j = j-1
                fitbit = fitbit+1
                direction = 'South'

        elif direction == 'West' and fitbit < (mapsize*mapsize)/2:
            if mapz[i][j+1] > 0:
                j = j+1
                fitbit = fitbit+1
                direction = 'North'
            elif mapz[i-1][j] > 0:
                i = i-1
                fitbit = fitbit+1
                direction = 'West'
            elif mapz[i][j-1] > 0:
                j = j-1
                fitbit = fitbit+1
                direction = 'South'
            else:
                i = i+1
                fitbit = fitbit+1
                direction = 'East'
        elif direction == 'South' and fitbit < (mapsize*mapsize)/2:
            if mapz[i-1][j] > 0:
                i = i-1
                fitbit = fitbit+1
                direction = 'West'
            elif mapz[i][j-1] > 0:
                j = j-1
                fitbit = fitbit+1
                direction = 'South'
            elif mapz[i+1][j] > 0:
                i = i+1
                fitbit = fitbit+1
                direction = 'East'
            else:
                j = j+1
                fitbit = fitbit+1
                direction = 'North'
        else:
            rand = random.randint(1, 4)
            if rand == 1:
                direction = 'North'
            elif rand == 2:
                direction = 'South'
            elif rand == 3:
                direction = 'East'
            else:
                direction = 'West'
            fitbit = fitbit+1
        mapz[i][j] = 8


    exit = 0
    while exit == 0:
        yesno = raw_input("\nWould you like to print some cool stuff for Right-Hand-Wall?\n")
        if yesno == 'no' or yesno == 'No' or yesno == 'n' or yesno == 'N':
            printm = makemap.printmap(mapz)
            exit = 1
        else:
            printm = makemap.printCool(mapz)
            exit =1


    if(fitbit == mapsize*mapsize):
        print "\nQUIT, STOP FOR THE LOVE OF GOD!\n"
    else:
        print "\nUsing the Right Hand method only took ", fitbit, " steps, young man/woman/whatever.\n"

    for i in range(len(mapz)):#resets map to its original
        for j in range(len(mapz[i])):
            if mapz[i][j] !=0:
                mapz[i][j]=1
        mapz[mapsize/2][mapsize/2]
        fitbit = 0




    #
