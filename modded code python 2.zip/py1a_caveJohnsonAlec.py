#py1a_cave.py created by Alec Johnson
import random
import math
from rightHandWall import rightHandWall#right hand wall method of escape
from rightRun import rightRun#right and run method of escape
import makemap#creates the map
from direction import setDirection
from seed import setSeed, setCommandLine, randoSeed
#Right hand wall tends to get stuck if there are "islands" of walls
#Essentially, if the walker does not start next to a right hand wall they keep turning
#right until the end of time.
#
#Right and Run tends to fail if there are two opposite dead end walls
#
#Both have issues with open spaces, I would call them both agoraphobic
#They work best in tight spaces with more defined walls
#
#The code prompts the user for a direction because I wanted to test whether or not the number of steps
#or solutions would change based on direction. So far, tests have proven mostly inconclusive
#If you would like to try this function, comment out line 36 and uncomment lines 34 and 35
#One of the things I tried to improve the Righ Hand Wall method was to add a random direction generator
#if the step counter reached a certain threshold(mapsize*mapsize)/2, this made the Righ Hand method hang up
# a lot less, but I attempted a similar thing with Right Run and it would freeze or just crash the program
# I believe this has to do with how Right Run works, with it being easier to catch into an infinite loop.
#Overall, I think Right Hand Wall is a better system albeit slower.

#The print functions for the solutions are built into them, given more time I would create a decision subroutine
#to print the maps in a neater fashion with characters or the standard way with 1s, 0s, 8s and a 5

mapsize = 20
x, y, fitbit = mapsize/2, mapsize/2, 0


seedee, cmd_check = setCommandLine()

if (cmd_check == 0):
    yesno = raw_input("\nWould you like to set the seed for the map? Or are you lazy and just going to do it via random? Yes/No?\n")
    if yesno == 'Yes' or yesno == 'Y' or yesno == 'y' or yesno == 'yes':
        seede = setSeed()
    else:
        seede = randoSeed()

mapz = makemap.makemap(mapsize, x, y, seedee)
mappnt = makemap.printmap(mapz)
#print "\nNow that you have the map, which direction will you choose?\n"
#direction = setDirection()#
direction = 'North'
rmap = rightHandWall(mapz, mapsize, fitbit, x, y, direction)#runs the Right-Hand-Wall method to escape the cave

runmap = rightRun(mapz, mapsize, fitbit, x, y, direction)#runs the Right-and-Run method to escape the cave

#if (rmap.fitbit < runmap.fitbit):
#    print "The right hand wall method was better"
#else:
#    print "The right and run method was better"
#print '\n'
print "\nHere's the original map you walked through, but prettier.\n"
mappnt = makemap.printCool(mapz)#prints a neater version of the map
