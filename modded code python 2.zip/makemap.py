def makemap(mapsize, x, y, seedv):#creates a 20x20 map

    import random
    mapz = [[0 for j in range(mapsize)] for i in range(mapsize)]
    count = 0
    px, py = 0,0


    while count < mapsize*mapsize and x>0 and y > 0 and x< mapsize-1 and y <mapsize-1:
        random.seed(seedv)
        rwalk = random.randint(1,4)#randomly generates a direction the map will go

        if rwalk == 1:
            y = y+1
            seedv = seedv+1
            count = count+1
        elif rwalk == 2:
            y = y-1
            seedv = seedv+1
            count = count+1
        elif rwalk == 3:
            x = x+1
            seedv = seedv+1
            count = count+1
        else:
            x = x-1
            seedv = seedv+1
            count = count+1
        mapz[x][y] = 1#sets value of position to 1
        mapz[mapsize/2][mapsize/2] = 5#sets center value to 5
    return mapz#returns array as a value which will be passed into the solution subroutines

def printmap(mapz):#takes the value that makemap creates and uses it to print a map
    	for i in range(len(mapz)): #this prints out the map
    		for j in range(len(mapz[i])):
    			print mapz[i][j],
    		print ' '
        print '\n'

def printCool(mapz):#takes the value that makemap creates and uses it to print a neater map
    	for i in range(len(mapz)): #this prints out the map
    		for j in range(len(mapz[i])):
                    if mapz[i][j] == 0:
                        print '',
                    elif mapz[i][j] ==1:
                        print '.',
                    elif mapz[i][j] ==5:
                        print 'x',#for center
                    else:
                        print '8',
    		print ''
        print '\n'
